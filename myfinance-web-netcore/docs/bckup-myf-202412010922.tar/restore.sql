--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Debian 14.8-1.pgdg120+1)
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE myf;
--
-- Name: myf; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE myf WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE myf OWNER TO admin;

\connect myf

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: planoconta; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.planoconta (
    id integer NOT NULL,
    nome character varying(255) NOT NULL,
    tipo character(1)
);


ALTER TABLE public.planoconta OWNER TO admin;

--
-- Name: planoconta_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.planoconta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planoconta_id_seq OWNER TO admin;

--
-- Name: planoconta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.planoconta_id_seq OWNED BY public.planoconta.id;


--
-- Name: transacao; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.transacao (
    id integer NOT NULL,
    historico character varying(255),
    tipo character varying(100),
    valor numeric(15,2),
    data timestamp without time zone,
    planocontaid integer NOT NULL
);


ALTER TABLE public.transacao OWNER TO admin;

--
-- Name: transacao_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.transacao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transacao_id_seq OWNER TO admin;

--
-- Name: transacao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.transacao_id_seq OWNED BY public.transacao.id;


--
-- Name: planoconta id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.planoconta ALTER COLUMN id SET DEFAULT nextval('public.planoconta_id_seq'::regclass);


--
-- Name: transacao id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transacao ALTER COLUMN id SET DEFAULT nextval('public.transacao_id_seq'::regclass);


--
-- Data for Name: planoconta; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.planoconta (id, nome, tipo) FROM stdin;
\.
COPY public.planoconta (id, nome, tipo) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: transacao; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.transacao (id, historico, tipo, valor, data, planocontaid) FROM stdin;
\.
COPY public.transacao (id, historico, tipo, valor, data, planocontaid) FROM '$$PATH$$/3342.dat';

--
-- Name: planoconta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.planoconta_id_seq', 1, false);


--
-- Name: transacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.transacao_id_seq', 1, false);


--
-- Name: planoconta planoconta_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.planoconta
    ADD CONSTRAINT planoconta_pkey PRIMARY KEY (id);


--
-- Name: transacao transacao_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT transacao_pkey PRIMARY KEY (id);


--
-- Name: transacao fk_planocontaid; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transacao
    ADD CONSTRAINT fk_planocontaid FOREIGN KEY (planocontaid) REFERENCES public.planoconta(id);


--
-- PostgreSQL database dump complete
--

